document.getElementById('registrationForm').addEventListener('submit', async (event) => {
  event.preventDefault();

  const formData = new FormData(event.target);
  const data = {
    nome: formData.get('nome'),
    email: formData.get('email'),
    telefone: formData.get('telefone'),
    cpf: formData.get('cpf')
  };

  try {
    const response = await fetch('http://localhost:5500/cadastrar-usuario', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    });
    
    const result = await response.json();
    document.getElementById('formMessage').textContent = result.message;
  } catch (error) {
    console.error('Erro ao enviar o formulário:', error);
    document.getElementById('formMessage').textContent = 'Erro ao enviar o formulário.';
  }
});