const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');

// Criação do aplicativo Express
const app = express();
app.use(cors());
app.use(bodyParser.json()); // Para interpretar os dados no formato JSON

// Configuração da conexão com o banco de dados
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',  // Substitua pelo seu usuário do MySQL
    password: 'Jqbu7418@', // Substitua pela sua senha do MySQL
    database: 'cadastro_usuarios' // Banco de dados onde estão as tabelas
});

// Conectar ao banco de dados
db.connect((err) => {
    if (err) {
        console.error('Erro ao conectar ao banco de dados: ' + err.stack);
        return;
    }
    console.log('Conectado ao banco de dados com sucesso!');
});

// Função auxiliar para adicionar zeros à frente para garantir 2 dígitos
const padZero = (num) => (num < 10 ? `0${num}` : num);

// Função para calcular a classificação de treino
const calcularClassificacao = (totalDuracao) => {
    if (totalDuracao <= 18000) return 'Iniciante'; // Até 5 horas semanais
    if (totalDuracao <= 36000) return 'Intermediário'; // De 6 a 10 horas semanais
    if (totalDuracao <= 72000) return 'Avançado'; // De 11 a 20 horas semanais
    return 'Extremamente Avançado'; // Acima de 20 horas semanais
};

// Função para buscar os registros de academia de um aluno
const getRegistrosAcademiaAluno = (numeroMatricula) => {
    return new Promise((resolve, reject) => {
        const query = 'SELECT * FROM registros_academia WHERE numero_matricula = ?';
        db.query(query, [numeroMatricula], (err, registros) => {
            if (err) return reject(err);
            resolve(registros);
        });
    });
};

// Função para verificar se o aluno existe no banco de dados
const verifyAlunoExists = (matricula) => {
    return new Promise((resolve, reject) => {
        const query = 'SELECT * FROM usuarios WHERE numero_de_matricula = ?';
        db.query(query, [matricula], (err, results) => {
            if (err) return reject(err);
            if (results.length === 0) return reject(new Error('Matrícula não encontrada.'));
            resolve(results[0]);
        });
    });
};


// ============================
// Área de catraca - entrada e saida
// ============================

// Função para registrar a entrada de um aluno
const registrarEntradaAluno = (matricula) => {
    return new Promise((resolve, reject) => {
        const query = 'INSERT INTO registros_academia (numero_matricula, data_entrada) VALUES (?, ?)'; 
        db.query(query, [matricula, new Date()], (err, results) => {
            if (err) return reject(err);
            resolve(results);
        });
    });
};

// Função para registrar a saída de um aluno
const registrarSaidaAluno = (matricula, duracaoStr) => {
    return new Promise((resolve, reject) => {
        const updateQuery = 'UPDATE registros_academia SET data_saida = ?, duracao = ? WHERE numero_matricula = ? AND data_saida IS NULL';
        db.query(updateQuery, [new Date(), duracaoStr, matricula], (err, result) => {
            if (err) return reject(err);
            resolve(result);
        });
    });
};


// ============================
// Área de cadastro - Rota
// ============================

// Importa o pacote 'cpf-cnpj-validator'
const { cpf } = require('cpf-cnpj-validator');

// Rota para cadastrar um novo usuário (cadastro)
app.post('/cadastrar_usuarios', (req, res) => {
    const { nome, email, telefone, cpf: cpfInput, matricula } = req.body;

    // Verifica se todos os campos estão presentes (cadastro)
    if (!nome || !email || !telefone || !cpfInput || !matricula) {
        return res.status(400).json({ message: 'Preencha todos os campos obrigatórios.' });
    }

    // Valida o CPF usando o pacote cpf-cnpj-validator
    if (!cpf.isValid(cpfInput)) {
        return res.status(400).json({ message: 'CPF inválido. Por favor, insira um CPF válido.' });
    }

    // Inserir o novo usuário no banco de dados (cadastro)
    const query = 'INSERT INTO usuarios (nome, email, telefone, cpf, numero_de_matricula) VALUES (?, ?, ?, ?, ?)';
    db.query(query, [nome, email, telefone, cpfInput, matricula], (err, result) => {
        if (err) {
            console.error('Erro ao cadastrar usuário:', err);
            return res.status(500).json({ message: 'Erro ao cadastrar o usuário.' });
        }

        res.status(200).json({ message: 'Usuário cadastrado com sucesso!' });
    });
});


// ============================
// Área do Gerente - Relatórios
// ============================

// Rota para o Relatório de Classificação dos Alunos
app.get('/relatorio_classificacao', (req, res) => {
    const query = `
        SELECT u.nome, u.numero_de_matricula, SUM(TIMESTAMPDIFF(SECOND, r.data_entrada, r.data_saida)) AS totalSegundos
        FROM usuarios u
        LEFT JOIN registros_academia r ON u.numero_de_matricula = r.numero_matricula
        GROUP BY u.numero_de_matricula
        ORDER BY totalSegundos DESC  -- Ordena do maior para o menor tempo de treino
    `;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Erro ao consultar relatório de classificação:', err);
            return res.status(500).json({ error: 'Erro ao consultar relatório de classificação.' });
        }

        const relatorio = results.map(aluno => {
            const totalDuracao = aluno.totalSegundos || 0;
            const classificacao = calcularClassificacao(totalDuracao);

            // Convertendo segundos para horas, minutos e segundos
            const horas = Math.floor(totalDuracao / 3600);
            const minutos = Math.floor((totalDuracao % 3600) / 60);
            const segundos = totalDuracao % 60;
            const duracaoStr = `${padZero(horas)}:${padZero(minutos)}:${padZero(segundos)}`;

            return {
                nome: aluno.nome,
                matricula: aluno.numero_de_matricula,
                totalDuracao: duracaoStr,
                classificacao
            };
        });

        res.json({ relatorio });
    });
});

// ============================
// Área do Aluno - (específico por matrícula)
// ============================

// Função para o Relatório de Aluno (específico por matrícula)
app.get('/relatorio_aluno', (req, res) => {
    const matricula = req.query.matricula;

    if (!matricula) {
        return res.status(400).json({ error: 'Matrícula não fornecida.' });
    }

    const query = `
        SELECT u.nome, u.numero_de_matricula, SUM(TIMESTAMPDIFF(SECOND, r.data_entrada, r.data_saida)) AS totalSegundos
        FROM usuarios u
        LEFT JOIN registros_academia r ON u.numero_de_matricula = r.numero_matricula
        WHERE u.numero_de_matricula = ?
        GROUP BY u.numero_de_matricula
    `;

    db.query(query, [matricula], (err, results) => {
        if (err) {
            console.error('Erro ao consultar relatório de aluno:', err);
            return res.status(500).json({ error: 'Erro ao consultar relatório de aluno.' });
        }

        if (results.length === 0) {
            return res.status(404).json({ error: 'Aluno não encontrado.' });
        }

        console.log('Resultado da consulta:', results); // Adicione esse log para verificar os dados retornados

        const aluno = results[0];
        const totalDuracao = aluno.totalSegundos || 0;
        const classificacao = calcularClassificacao(totalDuracao);

        // Convertendo segundos para horas, minutos e segundos
        const horas = Math.floor(totalDuracao / 3600);
        const minutos = Math.floor((totalDuracao % 3600) / 60);
        const segundos = totalDuracao % 60;
        const duracaoStr = `${padZero(horas)}:${padZero(minutos)}:${padZero(segundos)}`;

        const relatorio = {
            nome: aluno.nome,
            matricula: aluno.numero_de_matricula,
            totalDuracao: duracaoStr,
            classificacao
        };

        res.json({ relatorio });
    });
});


// ============================
// Área da Catraca - Rota para verificação é validação da matricula e calculo 
// ============================

// Rota para registrar a entrada de um aluno na (catraca - entrada)
app.post('/catraca/entrada', async (req, res) => {
    const { matricula } = req.body;

    if (!matricula) {
        return res.status(400).json({ message: 'Matrícula não fornecida.' });
    }

    try {
        // Verifica se o aluno existe antes de registrar a entrada (catraca - entrada)
        await verifyAlunoExists(matricula);

        // Registrar a entrada do aluno (catraca - entrada)
        await registrarEntradaAluno(matricula);

        res.status(200).json({ message: 'Entrada registrada com sucesso!' });
    } catch (err) {
        console.error('Erro:', err);
        res.status(500).json({ message: 'Erro ao registrar a entrada.' });
    }
});

// Rota para registrar a saída de um aluno na (catraca - entrada)
app.post('/catraca/saida', async (req, res) => {
    const { matricula } = req.body;

    if (!matricula) {
        return res.status(400).json({ message: 'Matrícula não fornecida.' });
    }

    try {
        // Verifica se o aluno existe antes de registrar a saída (catraca - saida)
        await verifyAlunoExists(matricula);

        // Calcular a duração com base na entrada e registrar a saída (catraca - saida)
        const registros = await getRegistrosAcademiaAluno(matricula);
        const ultimoRegistro = registros[registros.length - 1];

        if (!ultimoRegistro || ultimoRegistro.data_saida) {
            return res.status(400).json({ message: 'Entrada não registrada ou já saiu.' });
        }

        // Calcular a duração da entrada até a saída (catraca - saida)
        const entrada = new Date(ultimoRegistro.data_entrada);
        const saida = new Date();
        const duracaoSegundos = (saida - entrada) / 1000;

        // Converter a duração para o formato de horas:minutos:segundos (catraca - saida)
        const horas = Math.floor(duracaoSegundos / 3600);
        const minutos = Math.floor((duracaoSegundos % 3600) / 60);
        const segundos = duracaoSegundos % 60;
        const duracaoStr = `${padZero(horas)}:${padZero(minutos)}:${padZero(segundos)}`;

        // Registrar a saída (catraca - saida)
        await registrarSaidaAluno(matricula, duracaoStr);

        res.status(200).json({ message: 'Saída registrada com sucesso!' });
    } catch (err) {
        console.error('Erro:', err);
        res.status(500).json({ message: 'Erro ao registrar a saída.' });
    }
});

// ============================
// Área da Gerencial - Última semana
// ============================

app.get('/relatorio_gerencial', (req, res) => {
    const tipoRelatorio = req.query.tipo; // Tipo de relatório: totalHoras, ultimaSemana, ou classificacao

    let query;
    let params = [];

    // Se o tipo for totalHoras, soma o tempo de todos os registros
    if (tipoRelatorio === 'totalHoras') {
        query = `
            SELECT u.nome, u.numero_de_matricula, SUM(TIMESTAMPDIFF(SECOND, r.data_entrada, r.data_saida)) AS totalSegundos
            FROM usuarios u
            LEFT JOIN registros_academia r ON u.numero_de_matricula = r.numero_matricula
            GROUP BY u.numero_de_matricula
            ORDER BY totalSegundos DESC  -- Ordena do maior para o menor tempo de treino
        `;
    } 
    // Se o tipo for ultimaSemana, filtra os registros dos últimos 7 dias
    else if (tipoRelatorio === 'ultimaSemana') {
        const seteDiasAtras = new Date();
        seteDiasAtras.setDate(seteDiasAtras.getDate() - 7); // Subtrai 7 dias da data atual
        const seteDiasAtrasFormatada = seteDiasAtras.toISOString().slice(0, 19).replace('T', ' '); // Formato para SQL

        query = `
            SELECT u.nome, u.numero_de_matricula, SUM(TIMESTAMPDIFF(SECOND, r.data_entrada, r.data_saida)) AS totalSegundos
            FROM usuarios u
            LEFT JOIN registros_academia r ON u.numero_de_matricula = r.numero_matricula
            WHERE r.data_entrada >= ?
            GROUP BY u.numero_de_matricula
            ORDER BY totalSegundos DESC  -- Ordena do maior para o menor tempo de treino
        `;
        params = [seteDiasAtrasFormatada];
    } 
    // Se for o tipo de relatório de classificação
    else if (tipoRelatorio === 'classificacao') {
        query = `
            SELECT u.nome, u.numero_de_matricula, 
            SUM(TIMESTAMPDIFF(SECOND, r.data_entrada, r.data_saida)) AS totalSegundos
            FROM usuarios u
            LEFT JOIN registros_academia r ON u.numero_de_matricula = r.numero_matricula
            GROUP BY u.numero_de_matricula
            ORDER BY totalSegundos DESC  -- Ordena pelo total de segundos (classificação)
        `;
    } else {
        return res.status(400).json({ message: 'Tipo de relatório inválido.' });
    }

    // Executa a consulta no banco
    db.query(query, params, (err, results) => {
        if (err) {
            console.error('Erro ao consultar relatório gerencial:', err);
            return res.status(500).json({ error: 'Erro ao consultar relatório gerencial.' });
        }

        const relatorio = results.map(aluno => {
            const totalDuracao = aluno.totalSegundos || 0;
            const classificacao = calcularClassificacao(totalDuracao);

            // Convertendo segundos para horas, minutos e segundos
            const horas = Math.floor(totalDuracao / 3600);
            const minutos = Math.floor((totalDuracao % 3600) / 60);
            const segundos = totalDuracao % 60;
            const duracaoStr = `${padZero(horas)}:${padZero(minutos)}:${padZero(segundos)}`;

            return {
                nome: aluno.nome,
                matricula: aluno.numero_de_matricula,
                totalDuracao: duracaoStr,
                classificacao
            };
        });

        res.json({ relatorio });
    });
});


// Iniciar o servidor
app.listen(5500, () => {
    console.log('Servidor rodando na porta 5500');
});
