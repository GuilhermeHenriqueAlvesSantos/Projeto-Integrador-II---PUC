function gerarRelatorio() {
    const tipoRelatorio = document.getElementById('relatorioTipo').value;
    let relatorioHTML = '';

    if (tipoRelatorio === 'totalHoras') {
        relatorioHTML = "<h3>Relatório de Total de Horas de Treinamento de Todos os Alunos</h3>";
        fetch('http://localhost:5500/relatorio_gerencial?tipo=totalHoras')  
            .then(response => response.json())
            .then(data => {
                if (data && data.relatorio && Array.isArray(data.relatorio)) {
                    data.relatorio.forEach(aluno => {
                        relatorioHTML += `
                            <p><strong>${aluno.nome}</strong> (Matrícula: ${aluno.matricula})</p>
                            <p>Total de horas: ${aluno.totalDuracao}</p>
                            <p>Classificação: ${aluno.classificacao}</p>
                            <hr>
                        `;
                    });
                } else {
                    relatorioHTML += "<p>Erro ao obter dados do relatório. Tente novamente mais tarde.</p>";
                }
                document.getElementById("gerencialDados").innerHTML = relatorioHTML;
            })
            .catch(err => {
                alert('Erro ao consultar o relatório de horas.');
                console.error(err);
            });
    } else if (tipoRelatorio === 'classificacao') {
        relatorioHTML = "<h3>Relatório de Classificação de Todos os Alunos</h3>";
        fetch('http://localhost:5500/relatorio_classificacao')
            .then(response => response.json())
            .then(data => {
                if (data && data.relatorio && Array.isArray(data.relatorio)) {
                    data.relatorio.forEach(aluno => {
                        relatorioHTML += `
                            <p><strong>${aluno.nome}</strong> (Matrícula: ${aluno.matricula})</p>
                            <p>Classificação: ${aluno.classificacao}</p>
                            <hr>
                        `;
                    });
                } else {
                    relatorioHTML += "<p>Erro ao obter dados do relatório de classificação. Tente novamente mais tarde.</p>";
                }
                document.getElementById("gerencialDados").innerHTML = relatorioHTML;
            })
            .catch(err => {
                alert('Erro ao consultar relatório de classificação.');
                console.error(err);
            });
    } else if (tipoRelatorio === 'ultimaSemana') {
        relatorioHTML = "<h3>Relatório da Última Semana</h3>";
        fetch('http://localhost:5500/relatorio_gerencial?tipo=ultimaSemana')
            .then(response => response.json())
            .then(data => {
                if (data && data.relatorio && Array.isArray(data.relatorio)) {
                    data.relatorio.forEach(aluno => {
                        relatorioHTML += `
                            <p><strong>${aluno.nome}</strong> (Matrícula: ${aluno.matricula})</p>
                            <p>Total de horas (Última semana): ${aluno.totalDuracao}</p>
                            <p>Classificação: ${aluno.classificacao}</p>
                            <hr>
                        `;
                    });
                } else {
                    relatorioHTML += "<p>Erro ao obter dados do relatório da última semana. Tente novamente mais tarde.</p>";
                }
                document.getElementById("gerencialDados").innerHTML = relatorioHTML;
            })
            .catch(err => {
                alert('Erro ao consultar relatório da última semana.');
                console.error(err);
            });
    }
}
