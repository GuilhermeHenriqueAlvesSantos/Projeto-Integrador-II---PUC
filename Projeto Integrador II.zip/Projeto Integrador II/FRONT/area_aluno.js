// URL do back-end
const urlBase = 'http://localhost:5500';

// Consultar Relatório de Horas e Classificação
document.getElementById('consultarRelatorio').addEventListener('click', () => {
    const matricula = document.getElementById('matricula').value;

    if (!matricula) {
        alert('Por favor, insira sua matrícula.');
        return;
    }

    // Fazendo a requisição para o backend
    fetch(`${urlBase}/relatorio_aluno?matricula=${matricula}`)
        .then(response => {
            // Verifica se a resposta é válida
            if (!response.ok) {
                throw new Error(`Erro na requisição: ${response.statusText}`);
            }
            return response.json();
        })
        .then(data => {
            // Verifica se o formato dos dados é válido
            if (data && data.relatorio) {
                // Se a duração for inválida (NaN ou vazia), exibe uma mensagem padrão
                let duracaoDisplay = (data.relatorio.totalDuracao === "NaN:NaN:NaN" || !data.relatorio.totalDuracao) 
                    ? "Duração inválida" 
                    : data.relatorio.totalDuracao;

                // Exibe os resultados
                document.getElementById('resultados').classList.add('visible'); // Torna o bloco de resultados visível
                document.getElementById('duracaoTotal').innerHTML = `Total de horas: ${duracaoDisplay}`;
                document.getElementById('classificacao').innerHTML = `Classificação: ${data.relatorio.classificacao || 'Não disponível'}`;
            } else {
                alert('Dados inválidos retornados do servidor.');
            }
        })
        .catch(err => {
            // Exibe uma mensagem de erro se algo der errado
            alert(`Erro ao consultar relatório: ${err.message}`);
            console.error(err);
        });
});
