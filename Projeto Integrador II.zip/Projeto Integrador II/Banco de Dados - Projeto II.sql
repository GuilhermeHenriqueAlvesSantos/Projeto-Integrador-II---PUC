-- Se não existir, exclui o banco de dados e as tabelas
DROP DATABASE IF EXISTS cadastro_usuarios;
DROP TABLE IF EXISTS registros_academia;


-- Criação do banco de dados
CREATE DATABASE IF NOT EXISTS cadastro_usuarios;
USE cadastro_usuarios;

-- Tabela de usuários (Cadastro de Alunos)
CREATE TABLE IF NOT EXISTS usuarios (
    numero_de_matricula INT PRIMARY KEY AUTO_INCREMENT, 
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    telefone VARCHAR(15) NOT NULL,
    cpf VARCHAR(14) NOT NULL UNIQUE
);

-- Tabela de registros de academia (Controle de Entradas/Saídas)
CREATE TABLE IF NOT EXISTS registros_academia (
    id_registro INT PRIMARY KEY AUTO_INCREMENT,
    numero_matricula INT NOT NULL,
    data_entrada DATETIME NOT NULL,
    data_saida DATETIME,
    duracao TIME,  -- A duração será calculada quando necessário (não é mais uma coluna gerada)
    FOREIGN KEY (numero_matricula) REFERENCES usuarios(numero_de_matricula)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- Altera a senha do root (caso necessário)
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'Jqbu7418@';

-- Verifique as tabelas e as colunas criadas
SHOW TABLES LIKE 'registros_academia';
DESCRIBE registros_academia;



-- Consultas de teste para visualizar as tabelas e os dados
SELECT * FROM usuarios;
SELECT * FROM registros_academia;

INSERT INTO registros_academia (numero_matricula, data_entrada, data_saida, duracao)
VALUES (
    91473, 
    NOW(),  -- Hora atual como data de entrada
    DATE_ADD(NOW(), INTERVAL 20 HOUR),  -- Data de saída (20 horas após a entrada)
    '20:00:00'  -- Duração em formato de horas: minutos:segundos
);



-- Defina a matrícula do aluno
SET @matricula = '269448';

-- Defina a data de hoje
SET @hoje = NOW();

-- Inserir 7 dias de treino (2 horas por dia) para o aluno
INSERT INTO registros_academia (numero_matricula, data_entrada, data_saida, duracao)
VALUES
    (@matricula, DATE_SUB(@hoje, INTERVAL 0 DAY), DATE_SUB(@hoje, INTERVAL 0 DAY) + INTERVAL 2 HOUR, '02:00:00'), -- Hoje
    (@matricula, DATE_SUB(@hoje, INTERVAL 1 DAY), DATE_SUB(@hoje, INTERVAL 1 DAY) + INTERVAL 2 HOUR, '02:00:00'), -- Ontem
    (@matricula, DATE_SUB(@hoje, INTERVAL 2 DAY), DATE_SUB(@hoje, INTERVAL 2 DAY) + INTERVAL 2 HOUR, '02:00:00'), -- 2 dias atrás
    (@matricula, DATE_SUB(@hoje, INTERVAL 3 DAY), DATE_SUB(@hoje, INTERVAL 3 DAY) + INTERVAL 2 HOUR, '02:00:00'), -- 3 dias atrás
    (@matricula, DATE_SUB(@hoje, INTERVAL 4 DAY), DATE_SUB(@hoje, INTERVAL 4 DAY) + INTERVAL 2 HOUR, '02:00:00'), -- 4 dias atrás
    (@matricula, DATE_SUB(@hoje, INTERVAL 5 DAY), DATE_SUB(@hoje, INTERVAL 5 DAY) + INTERVAL 2 HOUR, '02:00:00'), -- 5 dias atrás
    (@matricula, DATE_SUB(@hoje, INTERVAL 6 DAY), DATE_SUB(@hoje, INTERVAL 6 DAY) + INTERVAL 2 HOUR, '02:00:00'); -- 6 dias atrás



